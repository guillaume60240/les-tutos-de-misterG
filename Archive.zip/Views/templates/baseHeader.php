<!-- Cette page sert à recevoir le contenu du header -->

    <?= $content ?>

