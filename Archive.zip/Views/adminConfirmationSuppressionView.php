

<div class="utilisateurs">
    <p class="textConfirm">Confirmer la suppression?
    </p>

    <form action="#" method="post" class="formulaireConfirm">
        <button type="submit" name="confirm"  value="<?= $_POST['supprimerUtilisateur'] ?>"class="btn">Oui</button>
        <a href="/?page=administration" class="btn">Non</a>
    </form>
</div>