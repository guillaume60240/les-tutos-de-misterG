<div class="partitionContainer">
    <h3 class="artistePartition"><?= $artiste ?></h3>
    <h4 class="titrePartition"><?= $title ?></h4>
    <a href="<?= $link ?>" class="linkPartition" target="_blank">Télécharger</a>
</div>