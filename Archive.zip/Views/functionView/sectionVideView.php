<div class="vid">
    <h3>Cette section est vide pour le moment</h3>
    <img src="../src/img/work-in-progress.png" alt="Travaille en cours" class="img-attente">
    
</div>