
<tr>
    <td><?=$pseudo?></td>
    <td><?=$date?></td>
    <td><?=$prenom?></td>
    <td><?=$nom?></td>
    <td><?=$ecole?></td>
    <td><?=$message?></td>
   
    <td><form action="#" method="post">  <button type="submit" class="btn"  name="supprimerDemande" value="<?=$id?>">Supprimer</button></form> </td>
</tr>
