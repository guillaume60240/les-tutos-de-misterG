
<tr>
    <td><?=$pseudo?></td>
    <td><?=$mail?></td>
    <td><?=$role?></td>
    <td><?=$date?></td>
    <td><form action="#" method="post">  <button type="submit" class="btn"  name="supprimerUtilisateur" value="<?=$id?>">Supprimer</button></form> </td>
</tr>
