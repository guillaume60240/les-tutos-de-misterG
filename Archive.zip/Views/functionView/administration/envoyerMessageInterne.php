<div class="utilisateurs">
<form action="#" method="post">
    <p>
        <span class="actionTitle">Nom de l'utilisateur </span></br>
        <p>
            <label for="recherche">Pseudo</label>
            <input type="text" name="pseudo" id="pseudo" >
            
            
        </p>
    </p>
    
    <p>
        <span class="actionTitle">Message:</span></br>
        <p>
           
            <textarea name="contenu" id="contenu" cols="30" rows="10">Message</textarea>
        </p>
    </p>
    <p>
        <button type="submit" name="createMessageInterne" class="btn" >Valider</button>
    </p>
</form>
</div>