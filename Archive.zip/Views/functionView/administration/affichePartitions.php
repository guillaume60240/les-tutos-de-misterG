
<tr>
    <td><?=$titre?></td>
    <td><?=$artiste?></td>
    <td><?=$created_at?></td>
    <td><?=$link?></td>
    <td><form action="#" method="post">  <button type="submit" class="btn"  name="supprimerPartition" value="<?=$id?>">Supprimer</button></form> </td>
</tr>