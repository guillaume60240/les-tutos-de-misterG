

<tr>
    <td><?=$pseudo?></td>
    <td><?=$date?></td>
    <td><?=$content?></td>
   
    <td><form action="#" method="post">  <button type="submit" class="btn"  name="supprimerCommentaire" value="<?=$id?>">Supprimer</button></form> </td>
</tr>
