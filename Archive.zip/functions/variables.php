<?php


    $dbName = 'les_tutos_de_mister_G';
    $userName = 'root';
    $mdp = 'root';
   
